import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Main {
    public static void main(String[] args) {
        ArrayList<Nodo> nodos = new ArrayList<>();
        Random random = new Random();


        for (int i = 0; i < 10; i++) {
            int rndmNum = random.nextInt(100);
            nodos.add(new Nodo(i, rndmNum));
        }

        System.out.println("listado numeros aleatorios");
        for (Nodo nodo : nodos) {
            System.out.println("id : " + nodo.id + ", Numero: " + nodo.data);
        }

        Collections.sort(nodos, (a, b) -> Integer.compare(a.data, b.data));

        System.out.println("listado numeros ordenados");
        for (Nodo nodo : nodos) {
            System.out.println("id : " + nodo.id + ", Numero: " + nodo.data);
        }
    }
}